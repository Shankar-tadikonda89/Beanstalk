#include <stdio.h>
#include <stdlib.h>
int VM, v, t = 0;
float *temp;
struct SJF {
int tasksid;
long int length;
float ET;
};
void sort(struct SJF sjf[], int N) {
int i, j;

struct SJF temp;
for (i = 0; i < N - 1; i++) {
for (j = 0; j < N - i - 1; j++) {
if (sjf[j].length > sjf[j + 1].length) {
temp = sjf[j];
sjf[j] = sjf[j + 1];
sjf[j + 1] = temp;
}
}
}
}
void wait(float w) {
static int i = 0;
if (VM-- && !t) {
printf("%6.2f\t\t", 0.00);
} else {
VM = v;
printf("%6.2f\t\t", temp[i % v]);
t = 1;
}
temp[i++ % v] += w;
}
int main() {
int Ntasks, i;
float tot = 0;
printf("Enter No of Tasks: ");
scanf("%d", &Ntasks);
struct SJF sjf[Ntasks];
for (i = 0; i < Ntasks; i++) {
sjf[i].tasksid = i + 1;
printf("Enter Length of Task%d: ", i + 1);
scanf("%ld", &sjf[i].length);
printf("Enter ET of Tasks%d: ", i + 1);
scanf("%f", &sjf[i].ET);
}
printf("Enter No of VM's: ");
scanf("%d", &VM);
v = VM;
temp = (float *)calloc(VM, sizeof(float));
sort(sjf, Ntasks);
printf("\nTasks\tET\t\tWaiting Time\tVM\n");
printf("----------------------------------------------\n");

for (i = 0; i < Ntasks; i++) {
printf("T%d\t", sjf[i].tasksid);
printf("%6.2f\t\t", sjf[i].ET);
wait(sjf[i].ET);
printf("VM%d\n", (i % v) + 1);
}
for (i = 0; i < v; i++) {
tot += temp[i];
}
printf("\nTotal Waiting Time (all tasks): %.2f\n", tot);
printf("Average Waiting Time: %.2f\n", tot / Ntasks);
free(temp);
return 0;
}