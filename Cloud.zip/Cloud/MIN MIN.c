#include <stdio.h>
#include <stdlib.h>
typedef struct {
int id;
double length;
double et;
double waitingTime;
int assignedVM;
} Task;
Task* createTask(int id, double length, double et) {
Task* task = (Task*)malloc(sizeof(Task));
task->id = id;
task->length = length;
task->et = et;
task->waitingTime = 0;
task->assignedVM = -1;
return task;
}
void swapTask(Task* a, Task* b) {
Task temp = *a;
*a = *b;
*b = temp;
}

void sortTasks(Task* tasks, int numTasks) {
for (int i = 0; i < numTasks - 1; i++) {
for (int j = 0; j < numTasks - i - 1; j++) {
if (tasks[j].et > tasks[j + 1].et) {
swapTask(&tasks[j], &tasks[j + 1]);
}
}
}
}
int main() {
int numTasks, numVMs;
printf("Enter the number of tasks: ");
scanf("%d", &numTasks);
printf("Enter the number of VMs: ");
scanf("%d", &numVMs);
Task* tasks = (Task*)malloc(numTasks * sizeof(Task));
double* vmCompletionTimes = (double*)malloc(numVMs * sizeof(double));
for (int i = 0; i < numTasks; i++) {
printf("Enter length for Task %d: ", i + 1);
scanf("%lf", &tasks[i].length);
printf("Enter execution time for Task %d: ", i + 1);
scanf("%lf", &tasks[i].et);
tasks[i].id = i + 1;
}
for (int i = 0; i < numVMs; i++) {
vmCompletionTimes[i] = 0;
}
sortTasks(tasks, numTasks);
printf("MIN-MIN Scheduling:\n");
double abb = 0;
double overallCompletionTime = 0;
for (int i = 0; i < numTasks; i++) {
double minTime = 1000000;
int minVM = -1;
for (int j = 0; j < numVMs; j++) {
double time = vmCompletionTimes[j] + tasks[i].et;
if (time < minTime) {
minTime = time;
minVM = j;

}
}
tasks[i].waitingTime = vmCompletionTimes[minVM];
vmCompletionTimes[minVM] = minTime;
tasks[i].assignedVM = minVM;
printf("Task t%d ET: %.2lf VM%d Waiting Time: %.2lf\n", tasks[i].id,
tasks[i].et, minVM + 1, tasks[i].waitingTime);
if (i >= numTasks - numVMs) {
abb += tasks[i].waitingTime;
}
}
for (int i = 0; i < numVMs; i++) {
if (vmCompletionTimes[i] > overallCompletionTime) {
overallCompletionTime = vmCompletionTimes[i];
}
}
double averageWaitingTime = abb / numVMs;
printf("Total Waiting Time = %.2lf\n", abb);
printf("Average Waiting Time = %.2lf\n", averageWaitingTime);
printf("Overall Completion Time = %.2lf\n", overallCompletionTime);
free(tasks);
free(vmCompletionTimes);
return 