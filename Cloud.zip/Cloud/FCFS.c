#include<stdio.h>
#include<stdlib.h>
int vm,v,t = 0;
float *temp;
void wait(float w) {
static int i = 0;
if (vm-- && !t) {
printf("%6.2f\t\t", 0.00);
} else {
vm = v;
printf("%6.2f\t\t", temp[i % v]);
t = 1;
}
temp[i++ % v] += w;
}
int main() {
int Ntasks, i;
float tot = 0;
printf("Enter No of Tasks: ");
scanf("%d", &Ntasks);
float *tasks = (float *)calloc(Ntasks, sizeof(float));
if (tasks == NULL) {
printf("Memory allocation failed!\n");
return -1;

}
for (i = 0; i < Ntasks; i++) {
printf("Enter the Execution Time of Task %d: ", i + 1);
scanf("%f", &tasks[i]);
}
printf("Enter No of VM's: ");
scanf("%d", &vm);
v = vm;
temp = (float *)calloc(vm, sizeof(float));
if (temp == NULL) {
printf("Memory allocation failed!\n");
free(tasks);
return -1;
}
printf("\nTask\tET\tWaitingTime\tVM\n");
printf("----------------------------------------------------\n");
for (i = 0; i < Ntasks; i++) {
printf("T%d\t", i + 1);
printf("%6.2f\t\t", tasks[i]);
wait(tasks[i]);
printf("VM%d\n", (i % v) + 1);
}
for(i = 0; i<v; i++) {
tot += temp[i];
}
printf("\nTotal Waiting Time (last 6 tasks): %.2f\n",tot);
printf("Average Waiting Time: %.2f\n",tot/v);
free(tasks);
free(temp);
return 0;
}