#include <stdio.h>
#include <stdlib.h>
typedef struct {
int id;
double length;
double et;
double waitingTime;
} Task;

Task* createTask(int id, double length, double et) {
Task* task = (Task*)malloc(sizeof(Task));
task->id = id;
task->length = length;
task->et = et;
task->waitingTime = 0;
return task;
}
void swapTask(Task* a, Task* b) {
Task temp = *a;
*a = *b;
*b = temp;
}
void swapInt(int* a, int* b) {
int temp = *a;
*a = *b;
*b = temp;
}
void swapDouble(double* a, double* b) {
double temp = *a;
*a = *b;
*b = temp;
}
void sortTasks(Task* tasks, int numTasks) {
for (int i = 0; i < numTasks - 1; i++) {
for (int j = 0; j < numTasks - i - 1; j++) {
if (tasks[j].length < tasks[j + 1].length) {
swapTask(&tasks[j], &tasks[j + 1]);
}
}
}

}
void sortVMIndices(int* vmIndices, double* vmMips, int numVMs) {
for (int i = 0; i < numVMs - 1; i++) {
for (int j = 0; j < numVMs - i - 1; j++) {
if (vmMips[vmIndices[j]] < vmMips[vmIndices[j + 1]]) {
swapDouble(&vmMips[vmIndices[j]], &vmMips[vmIndices[j + 1]]);
swapInt(&vmIndices[j], &vmIndices[j + 1]);
}
}
}
}
int main() {
int numTasks, numVMs;
printf("Enter the number of tasks: ");
scanf("%d", &numTasks);
printf("Enter the number of VMs: ");
scanf("%d", &numVMs);
Task* tasks = (Task*)malloc(numTasks * sizeof(Task));
double* vmMips = (double*)malloc(numVMs * sizeof(double));
double* vmCompletionTimes = (double*)malloc(numVMs * sizeof(double));
int* vmIndices = (int*)malloc(numVMs * sizeof(int));
for (int i = 0; i < numTasks; i++) {
printf("Enter length for Task %d: ", i + 1);
scanf("%lf", &tasks[i].length);
printf("Enter execution time for Task %d: ", i + 1);
scanf("%lf", &tasks[i].et);
tasks[i].id = i + 1;
}
for (int i = 0; i < numVMs; i++) {
printf("Enter MIPS value for VM%d: ", i + 1);
scanf("%lf", &vmMips[i]);
vmIndices[i] = i;
vmCompletionTimes[i] = 0;
}
sortTasks(tasks, numTasks);
sortVMIndices(vmIndices, vmMips, numVMs);
printf("Max-Min Scheduling:\n");
double abb = 0;
double overallCompletionTime = 0;

for (int i = 0; i < numTasks; i++) {
int vmIndex = i % numVMs;
tasks[i].waitingTime = vmCompletionTimes[vmIndex];
vmCompletionTimes[vmIndex] += tasks[i].et;
printf("Task t%d ET: %.2lf VM%d Waiting Time: %.2lf\n", tasks[i].id,
tasks[i].et, vmIndices[vmIndex] + 1, tasks[i].waitingTime);
if (i >= numTasks - numVMs) {
abb += tasks[i].waitingTime;
}
}
for (int i = 0; i < numVMs; i++) {
if (vmCompletionTimes[i] > overallCompletionTime) {
overallCompletionTime = vmCompletionTimes[i];
}
}
double averageWaitingTime = abb / numVMs;
printf("Total Waiting Time = %.2lf\n", abb);
printf("Average Waiting Time = %.2lf\n", averageWaitingTime);
printf("Overall Completion Time = %.2lf\n", overallCompletionTime);
free(tasks);
free(vmMips);
free(vmCompletionTimes);
free(vmIndices);
return 0;
}